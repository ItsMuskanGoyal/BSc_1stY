# CPUSIM-sem1

Download zip file from green code button 
and for solutions open solutions folder

Solutions folder contains 2 machines 
- practical_final for questions 1 to 12
- machine2_final for questions 13 to 15
